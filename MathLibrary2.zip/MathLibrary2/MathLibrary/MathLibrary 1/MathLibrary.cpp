#include <iostream>
#include "pch.h"
#include "MathLibrary.h"
using namespace std;

void triangle(int a, int b, int c, int h) {
	int P = a + b + c;
	int S = (a * h) / 2;
	cout << P << " " << S;
	
}
