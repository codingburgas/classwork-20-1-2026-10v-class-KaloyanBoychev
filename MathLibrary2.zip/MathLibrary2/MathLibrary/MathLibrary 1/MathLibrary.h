#pragma once
#include <iostream>
using namespace std;
void triangle(int a, int b, int c, int h);
