

#include <iostream>
#include "../MathLibrary 1/MathLibrary.h"
int main()
{

}

