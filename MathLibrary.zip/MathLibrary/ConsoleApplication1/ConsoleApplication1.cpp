

#include <iostream>
#include "../MathLibrary 1/MathLibrary.h"
using namespace std;
int main() {
	
		int a, b, c, h;
		cin >> a >> b >> c >> h;
		 triangle(a, b, c, h);
	
}

